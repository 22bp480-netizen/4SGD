import React from 'react';
import { 
  Palette, Moon, Sun, Monitor, 
  RefreshCcw, Sparkles, Shield, Bell
} from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { playClickSound, playPopSound } from '@/src/lib/audio';

interface SettingsProps {
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  accentColor: string;
  setAccentColor: (color: string) => void;
}

const themeColors = [
  { id: 'green', name: 'Sage Garden', muted: '#DCE4D1', strong: '#A3B18A', deep: '#4A5D23' },
  { id: 'blue', name: 'Ocean Calm', muted: '#B4D4EE', strong: '#547BA0', deep: '#2D4B6A' },
  { id: 'peach', name: 'Sunset Glow', muted: '#EAC0BD', strong: '#8C5F5B', deep: '#5C3D3A' },
  { id: 'yellow', name: 'Golden Hour', muted: '#F3E99F', strong: '#A69A3B', deep: '#6B6327' },
];

export default function Settings({ darkMode, setDarkMode, accentColor, setAccentColor }: SettingsProps) {
  return (
    <div className="max-w-4xl mx-auto space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      <header>
        <h2 className="text-3xl font-display font-extrabold text-natural-earth">Personalization</h2>
        <p className="text-text-muted italic">Craft an environment that feels like home.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Visual Settings */}
        <div className="space-y-6">
          <section className="bento-card p-6 space-y-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="p-2 bg-natural-blue-muted/30 rounded-xl text-natural-blue-strong">
                <Palette size={20} />
              </div>
              <h3 className="text-lg font-bold text-natural-earth">Appearance</h3>
            </div>

            {/* Dark Mode Toggle */}
            <div className="flex items-center justify-between p-4 bg-white/40 rounded-2xl border border-white/50">
              <div className="flex items-center gap-3">
                {darkMode ? <Moon size={20} className="text-natural-blue-strong" /> : <Sun size={20} className="text-natural-yellow-strong" />}
                <div>
                  <p className="font-bold text-sm">Dark Mode</p>
                  <p className="text-[10px] text-text-muted font-bold uppercase tracking-widest">Toggle night view</p>
                </div>
              </div>
              <button 
                onClick={() => {
                  playPopSound();
                  setDarkMode(!darkMode);
                }}
                className={cn(
                  "w-12 h-6 rounded-full transition-all relative p-1",
                  darkMode ? "bg-accent-strong" : "bg-natural-beige"
                )}
              >
                <div className={cn(
                  "w-4 h-4 rounded-full bg-white shadow-sm transition-all",
                  darkMode ? "translate-x-6" : "translate-x-0"
                )} />
              </button>
            </div>

            {/* Color Themes */}
            <div className="space-y-4">
              <p className="text-[10px] text-text-muted font-bold uppercase tracking-widest ml-1">Accent Theme</p>
              <div className="grid grid-cols-2 gap-3">
                {themeColors.map((theme) => (
                  <button
                    key={theme.id}
                    onClick={() => {
                      playClickSound();
                      setAccentColor(theme.id);
                    }}
                    className={cn(
                      "p-3 rounded-2xl border-2 transition-all flex flex-col gap-2 text-left",
                      accentColor === theme.id 
                        ? "border-accent-strong bg-white shadow-md ring-4 ring-accent-muted/20" 
                        : "border-transparent bg-white/40 hover:bg-white"
                    )}
                  >
                    <div className="flex gap-1">
                      <div className="w-4 h-4 rounded-full" style={{ backgroundColor: theme.strong }} />
                      <div className="w-4 h-4 rounded-full opacity-50" style={{ backgroundColor: theme.muted }} />
                    </div>
                    <span className="text-xs font-bold">{theme.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </section>

          <section className="bento-card p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-natural-green-muted/30 rounded-xl text-natural-green-strong">
                <Shield size={20} />
              </div>
              <h3 className="text-lg font-bold text-natural-earth">Data Management</h3>
            </div>
            <button 
              onClick={() => {
                if (confirm('Are you sure you want to clear all your progress? This cannot be undone.')) {
                  localStorage.clear();
                  window.location.reload();
                }
              }}
              className="w-full p-4 rounded-2xl bg-natural-peach-muted/20 text-natural-peach-strong border border-natural-peach-muted/50 font-bold text-sm hover:bg-natural-peach-muted/40 transition-all flex items-center justify-center gap-2"
            >
              <RefreshCcw size={16} /> Reset All Data
            </button>
          </section>
        </div>

        {/* Feature Toggles */}
        <div className="space-y-6">
          <section className="bento-card p-6 space-y-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-natural-yellow-muted/30 rounded-xl text-natural-yellow-strong">
                <Sparkles size={20} />
              </div>
              <h3 className="text-lg font-bold text-natural-earth">Preferences</h3>
            </div>

            <div className="space-y-3">
               {[
                 { icon: Bell, label: 'Push Notifications', desc: 'Study reminders' },
                 { icon: Monitor, label: 'Lumina AI Insights', desc: 'Personalized tips' },
               ].map((item, i) => (
                 <div key={i} className="flex items-center justify-between p-4 bg-white/40 rounded-2xl border border-white/50 opacity-60 cursor-not-allowed">
                    <div className="flex items-center gap-3">
                      <item.icon size={18} className="text-text-muted" />
                      <div>
                        <p className="font-bold text-sm">{item.label}</p>
                        <p className="text-[10px] text-text-muted font-bold uppercase tracking-widest">{item.desc}</p>
                      </div>
                    </div>
                    <div className="text-[9px] font-black uppercase text-natural-earth tracking-tighter bg-natural-beige px-2 py-1 rounded-md">Coming Soon</div>
                 </div>
               ))}
            </div>

            <div className="p-5 bg-natural-green-muted/20 rounded-2xl border border-dashed border-natural-green-strong/40">
               <p className="text-xs text-natural-earth leading-relaxed italic">
                 "Your environment shapes your habits. Lumina is designed to be a peaceful sanctuary for your mind. Keep exploring!"
               </p>
            </div>
          </section>

          <footer className="text-center py-4">
            <div className="text-[10px] font-bold text-text-muted uppercase tracking-widest mb-1">App Version 2.0.4</div>
            <p className="text-[9px] text-text-muted opacity-50 italic">Designed for focus. Built for growth.</p>
          </footer>
        </div>
      </div>
    </div>
  );
}
