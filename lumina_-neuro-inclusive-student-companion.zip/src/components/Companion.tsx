import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Cat, Sparkles, X, Heart } from 'lucide-react';
import { cn } from '@/src/lib/utils';
import { playPopSound, playClickSound } from '@/src/lib/audio';

const MOTIVATIONAL_QUOTES = [
  "You're doing purr-fectly fine!",
  "Keep that streak alive! I'm counting on you.",
  "Take a paws and breathe deeply.",
  "Every small step counts towards your big dreams.",
  "You are capable of amazing things!",
  "Stay paws-itive, better days are coming.",
  "Don't fur-get to acknowledge your progress!",
  "Your streak makes me so purr-oud!",
  "Cuddles to your hard work!",
  "Believe in yourself as much as I believe in snacks."
];

interface CompanionProps {
  streak?: number;
  currentMood?: string;
}

export default function Companion({ streak = 0, currentMood }: CompanionProps) {
  const [quote, setQuote] = useState(streak > 0 ? "Purr-fect streak you have there!" : MOTIVATIONAL_QUOTES[0]);
  const [isBubbleVisible, setIsBubbleVisible] = useState(false);
  const [isCatVisible, setIsCatVisible] = useState(true);
  const [showHearts, setShowHearts] = useState(false);

  useEffect(() => {
    if (currentMood) {
      if (currentMood === 'happy') setQuote("Wow, you're shining today! ✨");
      else if (currentMood === 'sad') setQuote("I'm here for you. *nuzzles* 🌸");
      else if (currentMood === 'overwhelmed') setQuote("Take a deep breath with me... 🧘‍♂️");
      else if (currentMood === 'tired') setQuote("Rest is productive too, you know. 💤");
      else if (currentMood === 'calm') setQuote("Peace feels good. Purr... 🍃");
      setIsBubbleVisible(true);
      setTimeout(() => setIsBubbleVisible(false), 5000);
    }
  }, [currentMood]);

  const handlePet = () => {
    playPopSound();
    setShowHearts(true);
    setQuote("Mrowr! *purr purr* 🐾");
    setIsBubbleVisible(true);
    
    setTimeout(() => {
      setShowHearts(false);
    }, 2000);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      if (isCatVisible && !showHearts) {
        setQuote(MOTIVATIONAL_QUOTES[Math.floor(Math.random() * MOTIVATIONAL_QUOTES.length)]);
        setIsBubbleVisible(true);
        setTimeout(() => setIsBubbleVisible(false), 8000);
      }
    }, 45000);

    return () => clearInterval(interval);
  }, [isCatVisible, showHearts]);

  return (
    <>
      {/* Toggle Button */}
      <div className="fixed top-6 right-6 z-[120]">
        <button 
          onClick={() => {
            playClickSound();
            setIsCatVisible(!isCatVisible);
          }}
          className={cn(
            "p-2 rounded-full shadow-lg transition-all border-2 border-accent-strong",
            isCatVisible ? "bg-white text-accent-strong" : "bg-accent-strong text-white"
          )}
        >
          <Cat size={20} />
        </button>
      </div>

      <AnimatePresence>
        {isCatVisible && (
          <motion.div
            drag
            dragConstraints={{ left: -300, right: 0, top: 0, bottom: 600 }}
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.5 }}
            className="fixed top-20 right-6 z-[100] flex flex-col items-center gap-2 pointer-events-auto cursor-grab active:cursor-grabbing"
          >
            <AnimatePresence>
              {isBubbleVisible && (
                <motion.div
                  initial={{ opacity: 0, y: -10, scale: 0.8 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -5, scale: 0.8 }}
                  className="bg-white dark:bg-zinc-800 p-3 rounded-2xl shadow-xl border-2 border-accent-strong relative max-w-[180px] mt-2"
                >
                  <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-3 h-3 bg-white dark:bg-zinc-800 border-l-2 border-t-2 border-accent-strong transform rotate-45" />
                  <p className="text-[11px] font-bold text-natural-earth dark:text-white italic text-center">
                    "{quote}"
                  </p>
                </motion.div>
              )}
            </AnimatePresence>

            <div className="relative group order-first">
              <AnimatePresence>
                {showHearts && (
                  <div className="absolute -top-20 left-1/2 -translate-x-1/2 pointer-events-none w-20 h-20">
                    {[1, 2, 3].map(i => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, y: 0, scale: 0.5, x: (i - 2) * 20 }}
                        animate={{ opacity: 1, y: -60, scale: 1.2, x: (i - 2) * 30 + (Math.random() - 0.5) * 10 }}
                        exit={{ opacity: 0 }}
                        transition={{ duration: 1.5, ease: "easeOut" }}
                        className="absolute"
                      >
                        <Heart className="text-natural-peach-strong fill-natural-peach-strong" size={16} />
                      </motion.div>
                    ))}
                  </div>
                )}
              </AnimatePresence>

              <motion.div
                whileHover={{ scale: 1.1 }}
                animate={{ 
                  y: currentMood === 'sad' ? [0, -1, 0] : currentMood === 'happy' ? [0, -8, 0] : [0, -3, 0],
                }}
                transition={{ 
                  y: { 
                    duration: currentMood === 'happy' ? 1 : currentMood === 'sad' ? 4 : 2, 
                    repeat: Infinity, 
                    ease: "easeInOut" 
                  },
                }}
                onClick={handlePet}
                className="bg-accent-muted/60 backdrop-blur-md p-4 rounded-full border-2 border-accent-strong shadow-lg relative cursor-pointer transition-all hover:rotate-3"
              >
                <div className="absolute -top-10 left-1/2 -translate-x-1/2 bg-natural-earth text-white text-[10px] font-bold px-2 py-0.5 rounded-full whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
                   {streak} Day{streak !== 1 ? 's' : ''} Streak
                </div>
                <div className="absolute -top-14 left-1/2 -translate-x-1/2 bg-white px-2 py-1 rounded-lg text-[8px] font-black uppercase text-accent-deep shadow-sm opacity-0 group-hover:opacity-100 transition-all group-hover:-top-16">
                  Pet Me!
                </div>
                <div className="relative">
                  <motion.div
                    animate={currentMood === 'overwhelmed' ? {
                      x: [0, -1, 1, -1, 1, 0],
                      transition: { repeat: Infinity, duration: 0.1 }
                    } : {}}
                  >
                    <Cat 
                      size={40} 
                      className={cn(
                        "transition-colors duration-500", 
                        currentMood === 'sad' ? 'text-natural-blue-muted' : 
                        currentMood === 'happy' ? 'text-natural-yellow-strong' :
                        'text-accent-deep'
                      )} 
                    />
                  </motion.div>
                </div>
                <div className="absolute -top-1 -right-1 bg-accent-strong text-white p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                  <Sparkles size={10} />
                </div>
              </motion.div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
