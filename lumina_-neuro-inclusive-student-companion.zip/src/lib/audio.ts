// Simple utility for playing UI sounds
const clickSfx = 'data:audio/wav;base64,UklGRjIAAABXQVZFZm10IBAAAAABAAEAIlYAAESsAAACABAAZGF0YRAAAABp/2n/af9p/2n/af9p/2n/af9p/w=='; // Very short subtle click placeholder

export function playClickSound() {
  try {
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3');
    audio.volume = 0.3;
    audio.play().catch(e => console.log('Audio play failed', e));
  } catch (err) {
    console.error('Audio error', err);
  }
}

export function playPopSound() {
  try {
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2568/2568-preview.mp3');
    audio.volume = 0.2;
    audio.play().catch(e => console.log('Audio play failed', e));
  } catch (err) {
    console.error('Audio error', err);
  }
}
